<?php
echo date('d-m-Y H:i:s');